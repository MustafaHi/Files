#include "sciter-x.h"
#include "sciter-x-window.hpp"

int rX = 200;
int rY = 200;
int rH = 800;
int rW = 1250;
static RECT wrc = { rX, rY, rX + rW, rY + rH };

#include "webview.h"

extern HINSTANCE ghInstance;


class frame : public sciter::window {
public:
	frame() : window(SW_CONTROLS | SW_MAIN, wrc) {}

	BEGIN_FUNCTION_MAP
	END_FUNCTION_MAP

};
using namespace sciter;
struct WEBVIEW : public sciter::event_handler {
	HWND this_hwnd;
	HELEMENT this_e;
	WEBVIEW() : this_hwnd(0), this_e(0) {}
public:
	virtual void attached(HELEMENT he) {
		this_e = he;
		sciter::dom::element self = sciter::dom::element::element(he);
		RECT rc = self.get_location(false);
		HWND parent = self.get_element_hwnd(true);

        HINSTANCE hInstance = GetModuleHandle(nullptr);
		WNDCLASSEX wc;
		ZeroMemory(&wc, sizeof(WNDCLASSEX));
		wc.cbSize = sizeof(WNDCLASSEX);
		wc.hInstance = hInstance;
		wc.lpszClassName = "webview";

		wc.lpfnWndProc =
			(WNDPROC)(+[](HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) -> int {
			switch (msg) {
			    case WM_CLOSE:
			    	DestroyWindow(hwnd);
			    	break;
			    default:
			    	return DefWindowProc(hwnd, msg, wp, lp);
			}
			});
 		RegisterClassEx(&wc);

		this_hwnd = CreateWindow("webview",
			"",
			WS_CHILD | WS_VSCROLL | WS_HSCROLL | WS_CLIPCHILDREN | WS_VISIBLE,
			0, 0,
			0, 0,
			self.get_element_hwnd(true),
			0,
			ghInstance,
			0);

		webview::webview w(false, &this_hwnd);
		w.navigate("https://en.m.wikipedia.org/wiki/Main_Page");

		self.attach_hwnd(this_hwnd);
	}
	virtual void detached(HELEMENT he) {

	}

};
struct WEBVIEW_factory : public sciter::behavior_factory {
	WEBVIEW_factory() : sciter::behavior_factory("WEBVIEW") {}

	virtual sciter::event_handler* create(HELEMENT he) { return new WEBVIEW(); }
};
WEBVIEW_factory WEBVIEW_factory_instance;

#include "resources.cpp"

int uimain(std::function<int()> run) {
	SciterSetOption(NULL, SCITER_SET_SCRIPT_RUNTIME_FEATURES, ALLOW_SOCKET_IO | ALLOW_FILE_IO | ALLOW_SYSINFO | ALLOW_EVAL);
	SciterSetOption(NULL, SCITER_SET_DEBUG_MODE, TRUE);
#ifdef WINDOWS
	SciterSetOption(NULL, SCITER_SET_GFX_LAYER, GFX_LAYER_D2D);
#endif

	sciter::archive::instance().open(aux::elements_of(resources));

	frame* pwin = new frame();
	pwin->load(WSTR("this://app/main.htm"));
	pwin->expand();
	
	return run();
}
